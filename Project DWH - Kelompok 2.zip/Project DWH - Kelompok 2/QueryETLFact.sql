USE OLAP_spoJIfy
-- ETL Table Fact

-- SalesFact ETL 
IF EXISTS(
	SELECT * From OLAP_spoJIfy..FilterTimeStamp
	Where TableName = 'SalesFact'
)
Begin
Select 
	AlbumCode,
	StaffCode,
	CustomerCode,
	TimeCode,
	SUM(TSD.Quantity * AD.AlbumPrice) as 'TotalSalesEarning',
	SUM(TSD.Quantity) as 'TotalAlbumSold'
From spoJIfy..TrSalesHeader TSH
Join spoJIfy..TrSalesDetail TSD on TSH.SalesID = TSD.SalesID
Join OLAP_spoJIfy..AlbumDimension AD on TSD.AlbumID = AD.AlbumID
Join OLAP_spoJIfy..StaffDimension SD on TSH.StaffID = SD.StaffID
Join OLAP_spoJIfy..CustomerDimension CD on TSH.CustomerID = CD.CustomerID
Join OLAP_spoJIfy..TimeDimension TD on TSH.SalesDate = TD.[Date]
Where SalesDate > (
	SELECT LastETL From OLAP_spoJIfy..FilterTimeStamp
	Where TableName = 'SalesFact'
)
Group by 
	AlbumCode,
	StaffCode,
	CustomerCode,
	TimeCode
End
Else
Begin
Select 
	AlbumCode,
	StaffCode,
	CustomerCode,
	TimeCode,
	SUM(TSD.Quantity * AD.AlbumPrice) as 'TotalSalesEarning',
	SUM(TSD.Quantity) as 'TotalAlbumSold'
From spoJIfy..TrSalesHeader TSH
Join spoJIfy..TrSalesDetail TSD on TSH.SalesID = TSD.SalesID
Join OLAP_spoJIfy..AlbumDimension AD on TSD.AlbumID = AD.AlbumID
Join OLAP_spoJIfy..StaffDimension SD on TSH.StaffID = SD.StaffID
Join OLAP_spoJIfy..CustomerDimension CD on TSH.CustomerID = CD.CustomerID
Join OLAP_spoJIfy..TimeDimension TD on TSH.SalesDate = TD.[Date]
Group by 
	AlbumCode,
	StaffCode,
	CustomerCode,
	TimeCode
End

---SalesFact ExecuteTask
IF EXISTS(
	SELECT * From OLAP_spoJIfy..FilterTimeStamp
	Where TableName = 'SalesFact'
)
Begin
	Update OLAP_spoJIfy..FilterTimeStamp
	Set LastETL = GETDATE()
	Where TableName = 'SalesFact'
End
Else
Begin
	Insert Into OLAP_spoJIfy..FilterTimeStamp Values
	('SalesFact' , GETDATE())
End

-- PurchaseFact ETL
IF EXISTS(
	SELECT * From OLAP_spoJIfy..FilterTimeStamp
	Where TableName = 'PurchaseFact'
)
Begin
Select 
	AlbumCode,
	SupplierCode,
	BranchCode,
	StaffCode,
	TimeCode,
	SUM(TPD.Quantity * AD.AlbumPrice) as 'TotalPurchaseCost',
	SUM(TPD.Quantity) as 'TotalbumPurchased'
From spoJIfy..TrPurchaseHeader TPH
Join spoJIfy..TrPurchaseDetail TPD on TPH.PurchaseID = TPD.PurchaseID
Join OLAP_spoJIfy..AlbumDimension AD on TPD.AlbumID = AD.AlbumID
Join OLAP_spoJIfy..SupplierDimension SP on TPH.SupplierID = SP.SupplierID
Join OLAP_spoJIfy..BranchDimension BD on TPH.BranchID = BD.BranchID
Join OLAP_spoJIfy..StaffDimension SD on TPH.StaffID = SD.StaffID
Join OLAP_spoJIfy..TimeDimension TD on TPH.PurchaseDate = TD.[Date]
Where PurchaseDate > (
	SELECT LastETL From OLAP_spoJIfy..FilterTimeStamp
	Where TableName = 'PurchaseFact'
)
Group by 
	AlbumCode,
	SupplierCode,
	BranchCode,
	StaffCode,
	TimeCode
End
Else
Begin
Select 
	AlbumCode,
	SupplierCode,
	BranchCode,
	StaffCode,
	TimeCode,
	SUM(TPD.Quantity * AD.AlbumPrice) as 'TotalPurchaseCost',
	SUM(TPD.Quantity) as 'TotalbumPurchased'
From spoJIfy..TrPurchaseHeader TPH
Join spoJIfy..TrPurchaseDetail TPD on TPH.PurchaseID = TPD.PurchaseID
Join OLAP_spoJIfy..AlbumDimension AD on TPD.AlbumID = AD.AlbumID
Join OLAP_spoJIfy..SupplierDimension SP on TPH.SupplierID = SP.SupplierID
Join OLAP_spoJIfy..BranchDimension BD on TPH.BranchID = BD.BranchID
Join OLAP_spoJIfy..StaffDimension SD on TPH.StaffID = SD.StaffID
Join OLAP_spoJIfy..TimeDimension TD on TPH.PurchaseDate = TD.[Date]
Group by 
	AlbumCode,
	SupplierCode,
	BranchCode,
	StaffCode,
	TimeCode
End

-- PurchaseFact ExecuteTask
IF EXISTS(
	SELECT * From OLAP_spoJIfy..FilterTimeStamp
	Where TableName = 'PurchaseFact'
)
Begin
	Update OLAP_spoJIfy..FilterTimeStamp
	Set LastETL = GETDATE()
	Where TableName = 'PurchaseFact'
End
Else
Begin
	Insert Into OLAP_spoJIfy..FilterTimeStamp Values
	('PurchaseFact' , GETDATE())
End

-- ETL PreoderFact
IF EXISTS(
	SELECT * From OLAP_spoJIfy..FilterTimeStamp
	Where TableName = 'PreoderFact'
)
Begin
Select 
	AlbumCode,
	CustomerCode,
	StaffCode,
	TimeCode,
	SUM(TPD.Quantity * AD.AlbumPrice) as 'TotalPreorderEarnings',
	SUM(TPD.Quantity) as 'TotalPreoderedAlbumCount'
From spoJIfy..TrPreOrderHeader TPH
Join spoJIfy..TrPreOrderDetail TPD on TPH.PreOrderID = TPD.PreOrderID
Join OLAP_spoJIfy..AlbumDimension AD on TPD.AlbumID = AD.AlbumID
Join OLAP_spoJIfy..CustomerDimension CD on TPH.CustomerID = CD.CustomerID
Join OLAP_spoJIfy..StaffDimension SD on TPH.StaffID = SD.StaffID
Join OLAP_spoJIfy..TimeDimension TD on TPH.PreOrderDate = TD.[Date]
Where PreOrderDate > (
	SELECT LastETL From OLAP_spoJIfy..FilterTimeStamp
	Where TableName = 'PreoderFact'
)
Group by 
	AlbumCode,
	CustomerCode,
	StaffCode,
	TimeCode
End
Else
Begin
Select 
	AlbumCode,
	CustomerCode,
	StaffCode,
	TimeCode,
	SUM(TPD.Quantity * AD.AlbumPrice) as 'TotalPreorderEarnings',
	SUM(TPD.Quantity) as 'TotalPreoderedAlbumCount'
From spoJIfy..TrPreOrderHeader TPH
Join spoJIfy..TrPreOrderDetail TPD on TPH.PreOrderID = TPD.PreOrderID
Join OLAP_spoJIfy..AlbumDimension AD on TPD.AlbumID = AD.AlbumID
Join OLAP_spoJIfy..CustomerDimension CD on TPH.CustomerID = CD.CustomerID
Join OLAP_spoJIfy..StaffDimension SD on TPH.StaffID = SD.StaffID
Join OLAP_spoJIfy..TimeDimension TD on TPH.PreOrderDate = TD.[Date]
Group by 
	AlbumCode,
	CustomerCode,
	StaffCode,
	TimeCode
End
-- PreoderFact ExecuteTask
IF EXISTS(
	SELECT * From OLAP_spoJIfy..FilterTimeStamp
	Where TableName = 'PreoderFact'
)
Begin
	Update OLAP_spoJIfy..FilterTimeStamp
	Set LastETL = GETDATE()
	Where TableName = 'PreoderFact'
End
Else
Begin
	Insert Into OLAP_spoJIfy..FilterTimeStamp Values
	('PreoderFact' , GETDATE())
End

-- ETL ReturnFact
IF EXISTS(
	SELECT * From OLAP_spoJIfy..FilterTimeStamp
	Where TableName = 'ReturnFact'
)
Begin
Select 
	AlbumCode,
	PurchaseCode,
	StaffCode,
	TimeCode,
	SUM(TRD.Quantity * AD.AlbumPrice) as 'TotalReturnCost',
	SUM(TRD.Quantity) as 'TotalReturnedAlbumCount'
From spoJIfy..TrReturnHeader TRH
Join spoJIfy..TrReturnDetail TRD on TRH.ReturnID = TRD.ReturnID
Join OLAP_spoJIfy..AlbumDimension AD on TRD.AlbumID = AD.AlbumID
Join OLAP_spoJIfy..PurchaseDimension PD on TRH.PurchaseID = PD.PurchaseID
Join OLAP_spoJIfy..StaffDimension SD on TRH.StaffID = SD.StaffID
Join OLAP_spoJIfy..TimeDimension TD on TRH.ReturnDate = TD.[Date]
Where ReturnDate > (
	SELECT LastETL From OLAP_spoJIfy..FilterTimeStamp
	Where TableName = 'ReturnFact'
)
Group by 
	AlbumCode,
	PurchaseCode,
	StaffCode,
	TimeCode
End
Else
Begin
Select 
	AlbumCode,
	PurchaseCode,
	StaffCode,
	TimeCode,
	SUM(TRD.Quantity * AD.AlbumPrice) as 'TotalReturnCost',
	SUM(TRD.Quantity) as 'TotalReturnedAlbumCount'
From spoJIfy..TrReturnHeader TRH
Join spoJIfy..TrReturnDetail TRD on TRH.ReturnID = TRD.ReturnID
Join OLAP_spoJIfy..AlbumDimension AD on TRD.AlbumID = AD.AlbumID
Join OLAP_spoJIfy..PurchaseDimension PD on TRH.PurchaseID = PD.PurchaseID
Join OLAP_spoJIfy..StaffDimension SD on TRH.StaffID = SD.StaffID
Join OLAP_spoJIfy..TimeDimension TD on TRH.ReturnDate = TD.[Date]
Group by 
	AlbumCode,
	PurchaseCode,
	StaffCode,
	TimeCode
End

-- ReturnFact ExecuteTask
IF EXISTS(
	SELECT * From OLAP_spoJIfy..FilterTimeStamp
	Where TableName = 'ReturnFact'
)
Begin
	Update OLAP_spoJIfy..FilterTimeStamp
	Set LastETL = GETDATE()
	Where TableName = 'ReturnFact'
End
Else
Begin
	Insert Into OLAP_spoJIfy..FilterTimeStamp Values
	('ReturnFact' , GETDATE())
End