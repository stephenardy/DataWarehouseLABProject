
--- ETL AlbumDimension
Select 
	AlbumID,
	AlbumName,
	AlbumPrice,
	AlbumGenre
From spoJIfy..MsAlbum

Select * From OLAP_spoJIfy..AlbumDimension

-- ETL SongDimension

Select 
	SongID,
	SongName,
	SongDuration
From spoJIfy..MsSong

Select * From OLAP_spoJIfy..SongDimension

-- ETL StaffDimension

Select
	StaffID,
	StaffName,
	StaffGender,
	StaffSalary 
From spoJIfy..MsStaff

Select * From OLAP_spoJIfy..StaffDimension

-- ETL CustomerDimension

Select
	CustomerID,
	CustomerName,
	CustomerAddress
From spoJIfy..MsCustomer

Select * From OLAP_spoJIfy..CustomerDimension

-- ETL BranchDimension
Select
	BranchID,
	BranchAddress,
	BranchPhone 
From spoJIfy..MsBranch

Select * From OLAP_spoJIfy..BranchDimension

-- ETL CityDimension

Select
	CityID,
	CityName,
	CityPopulation
From spoJIfy..MsCity

Select * From OLAP_spoJIfy..CityDimension
-- ETL SupplierDimension

Select
	SupplierID,
	CityID,
	SupplierName,
	SupplierPhone,
	SupplierEmail
From spoJIfy..MsSupplier

Select * From OLAP_spoJIfy..SupplierDimension

-- ETL PurchaseDimension

Select
	TPH.PurchaseID,
	PurchaseDate,
	Quantity
From spoJIfy..TrPurchaseDetail TPD JOIN spoJIfy..TrPurchaseHeader TPH
ON TPD.PurchaseID = TPH.PurchaseID

Select * From OLAP_spoJIfy..PurchaseDimension

-- ETL TimeDimension
IF Exists(
	SELECT * FROM OLAP_spoJIfy..FilterTimestamp
	WHERE TableName = 'Time Dimension')
BEGIN
	SELECT
	AllDate.[Date],
	[Day] = DAY(AllDate.[Date]),
	[Month] = MONTH(AllDate.[Date]),
	[Quarter] = DATEPART(Quarter,(AllDate.[Date])),
	[Year] = YEAR(AllDate.[Date])
	FROM(
		SELECT PurchaseDate as [Date]
		FROM spoJIfy..TrPurchaseHeader
	) as AllDate
	WHERE AllDate.[Date] > (
		SELECT LastETL FROM OLAP_spoJIfy..FilterTimestamp
		WHERE TableName = 'Time Dimension'
		)
END
ELSE
BEGIN
SELECT
	AllDate.[Date],
	[Day] = DAY(AllDate.[Date]),
	[Month] = MONTH(AllDate.[Date]),
	[Quarter] = DATEPART(Quarter,(AllDate.[Date])),
	[Year] = YEAR(AllDate.[Date])
	FROM(
		SELECT PurchaseDate as [Date]
		FROM spoJIfy..TrPurchaseHeader
	) as AllDate
END

-- TimeDimension ExecuteTask
IF EXISTS(
	SELECT * From OLAP_spoJIfy..FilterTimeStamp
	Where TableName = 'TimeDimension'
)
Begin
	Update OLAP_spoJIfy..FilterTimeStamp
	Set LastETL = GETDATE()
	Where TableName = 'TimeDimension'
End
Else
Begin
	Insert Into OLAP_spoJIfy..FilterTimeStamp Values
	('TimeDimension' ,�GETDATE())
End