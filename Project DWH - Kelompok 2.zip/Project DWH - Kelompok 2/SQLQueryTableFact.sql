
-- Create Table SalesFact
Create Table SalesFact(
AlbumCode int,
StaffCode int,
CustomerCode int,
TimeCode int,
TotalSalesEarning BIGINT,
TotalAlbumSold BIGINT
)
-- Create Table PurchaseFact
Create Table PurchaseFact (
AlbumCode int,
SupplierCode int,
BranchCode int,
StaffCode int,
TimeCode int,
TotalPurchaseCost BIGINT,
TotalAlbumPurchased BIGINT
)
-- Create Table PreoderFact
Create Table PreorderFact (
AlbumCode int,
CustomerCode int,
StaffCode int,
TimeCode int,
TotalPreorderEarnings BIGINT,
TotalPreorderedAlbumCount BIGINT
)
-- Create Table ReturnFact
Create Table ReturnFact (
AlbumCode int,
PurchaseCode int,
StaffCode int,
TimeCode int,
TotalReturnCost BIGINT,
TotalReturnedAlbumCount BIGINT
)
