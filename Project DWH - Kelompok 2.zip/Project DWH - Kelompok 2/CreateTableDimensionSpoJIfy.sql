CREATE DATABASE OLAP_spoJIfy
GO
USE OLAP_spoJIfy


-- Create Table AlbumDimension
Create Table AlbumDimension(
AlbumCode INT PRIMARY KEY IDENTITY,
AlbumID VARCHAR(8),
AlbumName VARCHAR (100),
AlbumPrice INT,
AlbumGenre VARCHAR(50),
ValidFrom DATETIME,
ValidTo DATETIME
)

-- Create Table SongDimension
Create Table SongDimension (
SongCode INT PRIMARY KEY IDENTITY,
SongID VARCHAR(8),
SongName VARCHAR (50),
SongDuration INT
)

-- Create Table StaffDimension
Create Table StaffDimension (
StaffCode INT PRIMARY KEY IDENTITY,
StaffID VARCHAR(8),
StaffName VARCHAR(50),
StaffGender VARCHAR(6),
StaffSalary INT,
ValidFrom DATETIME,
ValidTo DATETIME
)

-- Create Table CustomerDimension
Create Table CustomerDimension(
CustomerCode INT PRIMARY KEY IDENTITY,
CustomerID VARCHAR(8),
CustomerName VARCHAR(50),
CustomerAddress VARCHAR(50)
)

-- Create Table BranchDimension
Create Table BranchDimension (
BranchCode INT PRIMARY KEY IDENTITY,
BranchID VARCHAR(8),
BranchAddress VARCHAR(50)
)

-- Create Table CityDimension
Create Table CityDimension (
CityCode INT PRIMARY KEY IDENTITY,
CityID VARCHAR(8),
CityName VARCHAR(50),
CityPopulation INT,
ValidFrom DATETIME,
ValidTo DATETIME
)

-- Create Table SupplierDimension
Create Table SupplierDimension (
SupplierCode INT PRIMARY KEY IDENTITY,
SupplierID VARCHAR(8),
SupplierName VARCHAR(50),
SupplierPhone VARCHAR(10),
SupplierEmail VARCHAR(50)
)

-- Create Table PurchaseDimension
Create Table PurchaseDimension (
PurchaseCode INT PRIMARY KEY IDENTITY,
PurchaseID VARCHAR(8),
PurchaseDate DATE,
Quantity INT
)

-- Create Table TimeDimension
Create Table TimeDimension (
TimeCode INT PRIMARY KEY IDENTITY,
[Day] INT,
[Date] DATE,
[Month] INT,
[Quarter] INT,
[Year] INT
)

-- Create Table FilterTimeStamp
Create Table FilterTimeStamp (
TableName VARCHAR(50) PRIMARY KEY,
LastETL DATETIME
)